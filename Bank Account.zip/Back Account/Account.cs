﻿using System;

class Account
{
    public int AccountNumber { get; } //get - other parts of the code can retrieve the value of AccountNumber using object.AccountNumber
    public string OwnerName { get; }
    public double Balance { get; private set; } //set - only methods within the same class can modify the value of 
    public double MonthlyDepositAmount { get; private set; }

    // Static properties
    public static double MonthlyFee = 4.0;
    public static double MonthlyInterestRate = 0.0025;
    public static double MinimumInitialBalance = 1000;
    public static double MinimumMonthlyDeposit = 50;

    // Constructor
    public Account(string ownerName, double initialDeposit, double monthlyDeposit)
    {
        AccountNumber = GenerateAccountNumber();
        OwnerName = ownerName;
        Balance = initialDeposit;
        MonthlyDepositAmount = monthlyDeposit;
    }

    // Generate random account number 9XXXX
    private int GenerateAccountNumber()
    {
        Random random = new Random();
        return random.Next(90000, 99999);
    }

    // Update balance based on the number of months
    public void UpdateBalance(int numberOfMonths) //can modify Balance because within the class
    {
        for (int i = 0; i < numberOfMonths; i++)
        {
            Balance -= MonthlyFee; //monthly fee
            Balance *= (1 + MonthlyInterestRate); //add monthly interest
            Balance += MonthlyDepositAmount; //add monthly deposit
        }
    }
}