﻿using System;
using System.Collections.Generic;

namespace Lab4
{
    class Program
    {
        static void Main(string[] args)
        {
            int numberOfMonths = GetNumberOfMonths();
            List<Account> accounts = OpenAccounts();

            // Update balances
            foreach (var account in accounts)
            {
                account.UpdateBalance(numberOfMonths);
            }

            // Summary
            foreach (var account in accounts)
            {
                Console.WriteLine($"After {numberOfMonths} month, {account.OwnerName}'s account (#{account.AccountNumber}), has a balance of {account.Balance:C}");
            }
        }

        static int GetNumberOfMonths()
        {
            while (true)
            {
                Console.Write("Enter the number of months to deposit: ");
                if (int.TryParse(Console.ReadLine(), out int numberOfMonths) && numberOfMonths > 0)
                {
                    return numberOfMonths;
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a valid integer greater than 0.");
                }
            }
        }

        static List<Account> OpenAccounts()
        {
            List<Account> accounts = new List<Account>();

            while (true)
            {
                Console.Write("Enter Customer Name (or press enter to stop): ");
                string name = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(name))
                {
                    Console.WriteLine();
                    break;
                }

                double initialDeposit = GetValidDepositAmount("Initial", Account.MinimumInitialBalance);
                double monthlyDeposit = GetValidDepositAmount("Monthly", Account.MinimumMonthlyDeposit);

                // Create account
                Account account = new Account(name, initialDeposit, monthlyDeposit);
                accounts.Add(account);
            }
            return accounts;
        }

        static double GetValidDepositAmount(string depositType, double minimumAmount)
        {
            double depositAmount;
            while (true)
            {
                Console.Write($"Enter {depositType} Deposit Amount ({minimumAmount:C} or more): ");
                if (!double.TryParse(Console.ReadLine(), out depositAmount) || depositAmount < minimumAmount)
                {
                    Console.WriteLine($"Invalid input. {depositType} deposit must be at least {minimumAmount:C}.");
                }
                else
                {
                    return depositAmount;
                }
            }
        }
    }

    class Account
    {
        public static readonly double MinimumInitialBalance = 0;
        public static readonly double MinimumMonthlyDeposit = 0;

        public string OwnerName { get; private set; }
        public int AccountNumber { get; private set; }
        public double InitialBalance { get; private set; }
        public double MonthlyDeposit { get; private set; }
        public double Balance { get; private set; }

        public Account(string ownerName, double initialBalance, double monthlyDeposit)
        {
            OwnerName = ownerName;
            InitialBalance = initialBalance;
            MonthlyDeposit = monthlyDeposit;
            Balance = initialBalance;
            AccountNumber = GenerateAccountNumber();
        }

        private int GenerateAccountNumber()
        {
            // Generate a unique account number here
            return new Random().Next(1000, 9999);
        }

        public void UpdateBalance(int numberOfMonths)
        {
            for (int i = 0; i < numberOfMonths; i++)
            {
                Balance += MonthlyDeposit;
            }
        }
    }
}
